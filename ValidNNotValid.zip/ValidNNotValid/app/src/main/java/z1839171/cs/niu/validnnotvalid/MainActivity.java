package z1839171.cs.niu.validnnotvalid;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout lo = new LinearLayout(this);
        lo.setOrientation(LinearLayout.VERTICAL);

        ScrollView sv = new ScrollView(this);
        sv.addView(lo);

        final EditText et = new EditText(this);
        lo.addView(et);

        TextView tv = new TextView(this);
        lo.addView(tv);

        Button login = new Button(this);
        lo.addView(login);
        login.setBackgroundColor(Color.BLACK);
        login.setText("Log In");
        login.setTextColor(Color.WHITE);

        this.setContentView(sv);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailInput = et.getText().toString().trim();

                if (emailInput.isEmpty()) {
                    et.setError("Field can't be empty");

                } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
                    et.setError("Please enter a valid email address");

                }else if (Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
                    et.setError("Valid Email Address");

                }else {
                    et.setError(null);

                }
            }
        });


    }
}
