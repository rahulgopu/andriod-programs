package z1840147.niu.edu;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper
    {
    private static final String DATABASE_NAME = "candyDB";
        private static final String TABLE_NAME = "candyTable";
        private static final String ID = "id";
        private static final String PRICE = "price";
        private static final String NAME = "name";

        private static final int DATABASE_VERSION = 1;

        public DatabaseManager(@Nullable Context context)
        {
            super(context, DATABASE_NAME,null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            //String that contains the SQL statement to create the database
            String sqlCreate = "create table " + TABLE_NAME
                    + "( " + ID + " integer primary key autoincrement, "
                    + NAME + " text, "
                    + PRICE + " real )";

            //Create the database
            db.execSQL(sqlCreate);
        }//end onCreate

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
        //String that drops the old table if it exists
        String sqlDrop = "drop table if exists " + TABLE_NAME;

        //Drop the old table
        db.execSQL(sqlDrop);

        //Re-create the table
        onCreate(db);
        }//end onUpgrade

     public void insert( Candy candy)
     {
     //Get the database
     SQLiteDatabase database = getWritableDatabase();

     //String to insert data into the database
     String sqlInsert = "insert into " + TABLE_NAME
                       + " values( null, '" + candy.getName() + "', "
                       + "'" + candy.getPrice() + "' )";

     //Insert the data into the database
         database.execSQL(sqlInsert);

         //Close the database
         database.close();
     }//end of insert

    public ArrayList<Candy> selectAll()
    {
     //Stirng for getting the information from the database
     String sqlQuery = "select * from " + TABLE_NAME;

     //Get the database with the information
     SQLiteDatabase database = getWritableDatabase();

     //Create the cursor with all the database information
        Cursor cursor = database.rawQuery(sqlQuery, null);

     //Create the arraylist that will be eventually returned from the method
     ArrayList<Candy> candies = new ArrayList<>();

     //loop that willtransferthe information from cursor to arraylist
        while (cursor.moveToNext())
        {
         Candy currentCandy = new Candy( Integer.parseInt(cursor.getString(0)),
                                                          cursor.getString(1),
                                                          cursor.getDouble(2));

         //put the candy object into the arraylist
            candies.add(currentCandy);
        }

    //close the database
        database.close();

        //return the arraylist
        return candies;
    } //end selectAll


    public void deleteByID(int id)
    {
     //String with the sql command
     String sqlDelete = "delete from " + TABLE_NAME + " where " + ID + " = " + id;

     //Get the database
        SQLiteDatabase database = getWritableDatabase();

        //delete the candy from the database
        database.execSQL(sqlDelete);

        //close the database
        database.close();
    }//end deleteByID

    }//end DatabaseManager
