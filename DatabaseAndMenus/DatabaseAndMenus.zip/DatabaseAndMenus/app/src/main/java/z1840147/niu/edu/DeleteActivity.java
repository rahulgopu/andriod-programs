package z1840147.niu.edu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity
{
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        databaseManager = new DatabaseManager(this);
        updateView();
    }//end onCreate

    public void updateView()
    {

    } //end updateView

    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId)
        {
         databaseManager.deleteByID( checkedId );
            Toast.makeText(DeleteActivity.this, "candy deleted", Toast.LENGTH_SHORT).show();

            updateView();
        }
    }//end RadioButtonHandler

 }//end DeleteActivity



