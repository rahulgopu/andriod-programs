package edu.niu.cs.z1839171.async1example;

/*****************************************************************************************
 CSCI 522 - Portfolio 15 - Semester (Spring) Year - 2019

 Programmer(s): Rahul Reddy Gopu
 Section: 1
 TA: Harshith Desamsetti

 Purpose: Design a simple application that will demonstrate asynchronous tasks by simulating the downloading of
 information.

 ***************************************************************************************/

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private Button downloadBtn;
    private ProgressBar downloadPB;
    private TextView downloadTV, callbackTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Connect the data members to the screen objects
        downloadBtn = findViewById(R.id.downloadButton);

        downloadPB = findViewById(R.id.downloadProgressBar);

        downloadTV = findViewById(R.id.downloadTextView);
        callbackTV = findViewById(R.id.callbackTextView);
    }//end onCreate

    //Download Button
    public void startDownload(View view)
    {
        //disable the download button
        downloadBtn.setEnabled(false);

        //Create the async object
        DownloadAsyncTask task = new DownloadAsyncTask();

        //start teh async task
        task.execute();
    }//end startDownload

    //Reset Button
    public void doReset(View view)
    {
        //Reset the textView
        downloadTV.setText(R.string.download_start_label);
        callbackTV.setText(R.string.callbacks_label);

        //Reset the progressbar
        downloadPB.setProgress(0);

        //Unlock screen orientation
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }//end doReset

    //Inner Async task class
    private class DownloadAsyncTask extends AsyncTask< Void, Integer, Void >
    {
        int progressStatus;

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();

            //append message to the current contents of the middle textview
            callbackTV.setText( callbackTV.getText() + "\n\nLock the screen orientation" );

            //Lock the screen orientation
            int currentOrientation = getResources().getConfiguration().orientation;

            if( currentOrientation == Configuration.ORIENTATION_PORTRAIT)
            {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
            else
            {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }

            //Append another message
            callbackTV.setText( callbackTV.getText() + "\nInvoke onPreExecute()" );

            //initialize the progress
            progressStatus = 0;

            //Indicate the download progress
            downloadTV.setText(R.string.download_start_label);

            //append some messages before moving to doInBackground
            callbackTV.setText(callbackTV.getText() + "\nCompleted onPreExecute()");
            callbackTV.setText( callbackTV.getText() + "\nInvoke doInBackground()");
            callbackTV.setText( callbackTV.getText() + "\nDoing Background work....");

        }//end onPreExecute

        @Override
        protected Void doInBackground(Void... voids)
        {
            while (progressStatus < 100)
            {
                progressStatus += 2;

                //Display the progress
                publishProgress(progressStatus);

                //delay
                SystemClock.sleep(300);
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values)
        {
            super.onProgressUpdate(values);

            //update the progressbar
            downloadPB.setProgress( values[0] );

            //update the textView for the download
            downloadTV.setText( "downloading " + values[0] + "%");
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {
            super.onPostExecute(aVoid);

            //append message to the middle textView
            callbackTV.setText(callbackTV.getText() + "\nCompleted Background work");
            callbackTV.setText( callbackTV.getText() + "\nInvoke onPostExecute()");

            //Complete the download message
            downloadTV.setText("Download Complete");

            //Re-enable the download button
            downloadBtn.setEnabled(true);
        }//end onPost
    }//end DownloadAsyncTask
}//end MainActivity
