/***************************************************************************
 * Instructor Name : Amy Byrnes
 *
 * ASSIGNMENT : 5 - To Do List
 *
 * Assignment Team Members : 1) Rahul Reddy Gopu (Z1839171)
 *                           2) Saran Kumar Reddy Padala (Z1840816)
 *
 * Purpose : To write an application that will use a database to store information.
 *          The application should function as a list-making tool.
 *
 * Assignment Due Date : Thursday, May 2 on Blackboard by 11:59 PM
 ***************************************************************************/
package edu.cs.niu.assign5.list;

public class Item {
    private int id,flag;
    private String name;
    public Item(int id, String name) {
        this.id = id;
        this.name = name;
        this.flag = 0;
    }
    public Item(int id, String name, int flag) {
        this.id = id;
        this.name = name;
        this.flag = flag;
    }
    public int getFlag() {
        return flag;
    }
    public void setFlag(int flag) {
        this.flag = flag;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String toString()
    {
        return id + " " + name ;
    }
}
