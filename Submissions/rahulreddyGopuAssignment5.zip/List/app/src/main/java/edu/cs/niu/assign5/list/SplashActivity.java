/***************************************************************************
 * Instructor Name : Amy Byrnes
 *
 * ASSIGNMENT : 5 - To Do List
 *
 * Assignment Team Members : 1) Rahul Reddy Gopu (Z1839171)
 *                           2) Saran Kumar Reddy Padala (Z1840816)
 *
 * Purpose : To write an application that will use a database to store information.
 *          The application should function as a list-making tool.
 *
 * Assignment Due Date : Thursday, May 2 on Blackboard by 11:59 PM
 ***************************************************************************/
package edu.cs.niu.assign5.list;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;



public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
