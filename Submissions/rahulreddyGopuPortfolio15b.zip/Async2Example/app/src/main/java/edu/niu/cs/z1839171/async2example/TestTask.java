package edu.niu.cs.z1839171.async2example;

/*****************************************************************************************
 CSCI 522 - Portfolio 15b - Semester (Spring) Year - 2019

 Programmer(s): Rahul Reddy Gopu
 Section: 1
 TA: Harshith Desamsetti

 Purpose: To design a simple application that will get a number from the user and use an asynchronous task to display the
 number on the screen.

 ***************************************************************************************/

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

public class TestTask extends AsyncTask<Integer, Void, String>
{
    private MainActivity activity;

    public TestTask(MainActivity fromActivity)
    {
        Log.w("MainActivity", "Inside the TestTask constructor");

        activity = fromActivity;
    }//end constructor

    @Override
    protected String doInBackground(Integer... integers)
    {
        Log.w("MainActivity", "Inside the doInBackground");

        //Create a string to be displayed
        String displayStr = "Your favourite number is " + integers[0] + "\nChangedby asynctask";

        return displayStr;
    }

    @Override
    protected void onPostExecute(String s)
    {
        super.onPostExecute(s);

        activity.updateView(s);
    }
}//end TestTask
